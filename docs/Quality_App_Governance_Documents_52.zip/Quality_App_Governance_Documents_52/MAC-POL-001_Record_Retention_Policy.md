# Record Retention Policy - CMMC Level 2

**Document ID:** MAC-POL-227  
**Document Version:** 1.0  
**Date:** 2026-03-02  
**Classification:** Internal Use  
**Compliance Framework:** CMMC 2.0 Level 2 (Advanced)  
**Reference:** NIST SP 800-171 Rev. 2 (e.g., 3.3.1 AU-11 Audit Record Retention); contractual and legal retention requirements

**Applies to:** CMMC 2.0 Level 2 (FCI and CUI system)

---

## 1. Policy Statement

MacTech Solutions establishes a consistent record retention schedule for security, compliance, and business records to support accountability, incident investigation, audits, and legal or contractual obligations. This policy defines minimum retention periods, storage and protection requirements, and authorized destruction of records.

This policy aligns with CMMC Level 2 requirements, NIST SP 800-171 Rev. 2 (including audit and accountability), and provides the organizational Records Retention Policy referenced by MacTech procedures and evidence practices.

---

## 2. Scope

This policy applies to:
- All records created or maintained in support of CUI/FCI system security and compliance
- All personnel and roles responsible for creating, storing, or disposing of such records
- Electronic and physical records within the scope of the MacTech CUI enclave and related governance

**Out of scope:** Records retention for purely commercial or non–security-related business functions may be governed by separate organizational or contractual requirements; where those overlap with security evidence, the longer retention period applies.

---

## 3. Definitions

- **Record:** Documented evidence (electronic or physical) of an action, decision, configuration, or event that may be needed for accountability, audit, or compliance.
- **Retention period:** Minimum length of time a record must be kept before it may be eligible for destruction in accordance with this policy.
- **Security and compliance records:** Records generated to satisfy CMMC, NIST SP 800-171, or contract-specific security and privacy requirements (e.g., access reviews, visitor logs, sanitization logs, training completion, audit logs, assessments).

---

## 4. General Retention Requirements

### 4.1 Default Minimum Retention: Security and Compliance Records

Unless a specific category below specifies otherwise, **security and compliance records** shall be retained for a **minimum of three (3) years** from the date of creation or the date of the last activity reflected in the record, whichever is later.

This default supports:
- CMMC and NIST 800-171 assessment and audit needs
- Incident investigation and after-action review
- Contractual and regulatory expectations for evidence retention

### 4.2 Audit Logs (System and Application)

- **Minimum retention:** 90 days for active (queryable) audit logs, unless a longer period is configured.
- Implementation of audit log retention is documented in the Audit and Accountability Policy (MAC-POL-218) and supporting evidence (e.g., MAC-RPT-107). Export or archive of audit logs for periods beyond the system default may be retained per the **three (3) year** minimum in Section 4.1 when retained as compliance evidence.

### 4.3 Categories with Explicit Retention

| Record category | Minimum retention | Notes |
|-----------------|-------------------|--------|
| Access control and access reviews (e.g., role/permission docs, access review records) | 3 years | Per MAC-SOP-253 |
| Visitor access logs and visitor authorization records | 3 years | Per MAC-SOP-249 |
| Sanitization and disposal logs (media/equipment, date, method, responsible party) | 3 years | Per MAC-SOP-246 |
| CUI marking, handling, and (where applicable) access logs | 3 years | Per MAC-SOP-248 |
| Media handling and transport logs | 3 years | Per MAC-SOP-247 |
| Cryptographic key management (e.g., plan summary, access/rotation records) | 3 years | Per MAC-SOP-251 |
| Boundary/network security (e.g., NSG/firewall exports, network diagram, VPN summary) | 3 years | Per MAC-SOP-250 |
| System inventory and asset change/decommissioning records | 3 years | Per MAC-SOP-252 |
| Security awareness training completion records | 3 years | Per MAC-POL-219 / MAC-SOP-227 |
| Personnel screening and termination-related records | Per HR/legal and contract; minimum 3 years for security-related entries | Per MAC-SOP-233, MAC-SOP-234 |
| Self-assessment and assessment-related records (e.g., annual assessments, attestations) | Minimum 3 years | Per Annual Self-Assessment Process |
| Incident response and incident-related records | Minimum 3 years | Per MAC-POL-215 and incident procedures |

Where a contract, regulation, or law requires a **longer** retention period, that longer period takes precedence.

---

## 5. Storage and Protection

- **Electronic records:** Stored in approved locations (e.g., compliance repository, secure share, or system of record) with access limited to authorized personnel per Access Control Policy (MAC-POL-210). Audit logs are protected per MAC-POL-218.
- **Physical records:** Stored in a controlled environment; access and handling per Physical Security Policy (MAC-POL-212) and related procedures.
- **Integrity:** Records shall not be altered, deleted, or destroyed before the end of their retention period except as part of an authorized, documented process (e.g., legal hold, correction of clearly erroneous data with approval).

---

## 6. Destruction and Disposal

- **Eligibility:** Records may be destroyed only after the applicable retention period has expired and there is no known legal hold, audit, or investigation requiring their preservation.
- **Method:** Electronic records shall be disposed of in a manner that prevents recovery (e.g., secure delete or storage deallocation per Media Sanitization Procedure MAC-SOP-246 where applicable). Physical records shall be destroyed per MAC-SOP-246 (e.g., cross-cut shredding for sensitive/printed CUI).
- **Documentation:** Disposal of records may be documented where required by procedure or for high-sensitivity categories; such disposal logs are retained per this policy (e.g., 3 years).

---

## 7. Roles and Responsibilities

- **System Owner / Compliance:** Ensure retention periods are communicated, procedures reference this policy, and periodic checks are performed to align practice with this policy.
- **Record custodians (e.g., admins, process owners):** Retain records for the required period, store them in approved locations, and dispose of them only in accordance with this policy and related procedures.
- **Security / Audit:** May rely on this policy when requesting evidence and when reviewing retention and disposal practices during assessments.

---

## 8. Related Documents

- Audit and Accountability Policy: `MAC-POL-218_Audit_and_Accountability_Policy.md`
- Media Sanitization Procedure: `MAC-SOP-246_Media_Sanitization_Procedure.md`
- Media Handling & Data Disposal Policy: `MAC-POL-213_Media_Handling_Policy.md`
- Access Control Policy: `MAC-POL-210_Access_Control_Policy.md`
- Annual Self-Assessment Process: `../04-self-assessment/Annual_Self_Assessment_Process.md`
- Audit Log Retention Evidence: `../05-evidence/MAC-RPT-107_Audit_Log_Retention_Evidence.md`

Procedures that reference “Records Retention Policy” or “Record Retention Policy” are satisfied by this document (MAC-POL-227).

---

## 9. Document Control

**Prepared By:** MacTech Solutions Compliance Team  
**Reviewed By:** [To be completed]  
**Approved By:** [To be completed]  
**Next Review Date:** [To be completed]

**Change History:**
- Version 1.0 (2026-03-02): Initial document creation; establishes organizational record retention for CMMC Level 2 and NIST SP 800-171 alignment.
